# vvsplit redesign — handoff package

This bundle is a drop-in redesign of your `vvsplit` PyScript app. The visual
direction is **Dashboard** (Stripe-flavored: Inter, indigo + navy, soft
gradients, generous space).

The design is **already wired into PyScript** — these aren't static mocks. The
files below are production-ready Python + HTML + CSS that replace the
Material 3 build while preserving every existing feature and the
`splitcore.*` calculation layer.

---

## Quick start

Copy the contents of `app/` into the root of your `vvsplit` repo, overwriting:

| File                       | Status   |
| -------------------------- | -------- |
| `index.html`               | replaced |
| `styles.css`               | replaced |
| `ui.py`                    | replaced |
| `splitcore/model.py`       | **edited** (added `trip_name` to `AppState`) |
| `main.py`                  | unchanged (included for completeness) |
| `storage.py`               | unchanged |
| `splitcore/__init__.py`    | unchanged |
| `splitcore/calc.py`        | unchanged |
| `pyscript.toml`            | unchanged |

Then serve the folder over HTTP and load `index.html`. (PyScript needs an HTTP
origin, not `file://`.)

```sh
python -m http.server 8000
# open http://localhost:8000
```

Existing localStorage saves keep working — `AppState.from_dict` now reads an
optional `trip_name` and tolerates its absence on old blobs.

---

## What changed vs. the original repo

### Visual system
- **Stack**: Inter (400/500/600/700/800), single-font, no serif.
- **Surface**: white app on `#f6f9fc` with soft borders (`#e3e8ee`), `8/12/16/20px` radii.
- **Brand accent**: `--indigo: #635bff`, `--indigo-soft: #f0eefe`.
- **Iridescent gradient** (`--hero-gradient`) used only on the brand mark and the hero `$total` accent.
- **Shadow scale**: `--sh-1` for resting cards, `--sh-3` for the floating total card.
- **Numbers**: `font-variant-numeric: tabular-nums` everywhere money is shown.
- **No hand-written JavaScript.** Every DOM update goes through `ui.py`.

### Layout
- Sticky translucent top bar with the brand, an editable **trip-name input**, and a "Saved locally" status pill.
- **Hero panel** with the gradient `$total`, a sub-line that reads naturally ("3 items billed across 4 people. It takes 3 transfers to settle up."), and a 2×2 stat grid.
- Right-hand **total card** that swaps between three states: *Empty*, *All square*, and *N transfers* with payer/debtor callouts.
- Two-column workflow below the hero — inputs on the left (People, Add expense), results on the right (Activity, Each person's share, Settle up).
- **Single-column collapse at 980px**; mobile-specific item-row grid below 600px.

### `ui.py` changes
- Rendering helpers `_avatar()`, `_item_icon()`, `_money()`, `_money_plain()` produce the new DOM (initials avatars, keyword-matched item icons, badges, transfer rows).
- New render functions: `_render_hero`, `_render_shares`, `_render_settle`, `_update_helper`, `_update_counts`. The old `_render_results` is gone — its job is split across hero + shares + settle.
- `_render_item_form(preserve=False)` — switching split mode no longer resets payer + participant selections.
- A small `_paid_by_id()` derives "Alex paid $84.20" lines for the people list and hero stats.
- "Saved locally" pill (`#saved-pill`) reflects three states: `saved`, `saving`, `error`.
- Empty states everywhere ("No people yet…", "No expenses yet…", "All settled — no transfers needed.").
- `Enter` in the *Add a person* field also submits.

### `splitcore/model.py` change
- `AppState.__init__` gains a `trip_name=""` parameter.
- `to_dict()` / `from_dict()` round-trip it. Bad/missing values fall back to `""`.

No changes to `splitcore/calc.py` — all math is unchanged.

---

## Per-item icons

`ui.py:_icon_kind()` maps a description keyword to one of six glyphs:

| Keyword(s) (any)                                  | Icon       |
| ------------------------------------------------- | ---------- |
| `coffee`, `latte`, `espresso`, `tea`…             | coffee cup |
| `wine`, `beer`, `cocktail`, `drink`…              | bottle     |
| `cab`, `taxi`, `uber`, `train`, `flight`…         | car        |
| `dinner`, `lunch`, `pizza`, `sushi`, `restaurant`…| fork       |
| `groceries`, `market`, `supermarket`…             | grocery bag|
| `hotel`, `airbnb`, `motel`, `lodging`…            | house      |
| anything else                                     | receipt    |

To extend, edit the `_ICON_KEYWORDS` list and add a new entry to `_ICON_PATHS`.
The SVG markup is hardcoded and goes through `innerHTML` from a fixed dict —
no user text ever flows into the SVG string.

---

## Avatars

Neutral single style: `--indigo` on `--indigo-soft`, initials derived in
`_initials()` (`Alex Chen → AC`, `Sam → SA`). To switch to per-person colored
avatars later, change `.avatar` in `styles.css` and have `_avatar()` add a
modifier class based on a stable hash of `person.id`.

---

## Trip name

A cosmetic-only string stored on `AppState.trip_name`. The top-bar input
saves on `change`/`blur`. No calculation depends on it.

---

## Design tokens (extract for any future component work)

```
/* surfaces */         #ffffff, #f6f9fc, #eef2f7, #e3e8ee
/* ink */              #0a2540, #3c4257, #6b7280, #94a3b8
/* indigo */           #635bff, #5046e4, #f0eefe
/* status */           success #00b878, danger #df1b41, warn #b45309
/* radii */            6, 8, 12, 16, 20
/* shadows */          sh-1: 0 1px 2px rgba(50,50,93,.06), 0 1px 1px rgba(0,0,0,.04)
                       sh-2: 0 2px 5px rgba(50,50,93,.08), 0 1px 2px rgba(0,0,0,.05)
                       sh-3: 0 7px 14px rgba(50,50,93,.10), 0 3px 6px rgba(0,0,0,.07)
/* ease */             cubic-bezier(.2, .8, .2, 1)
/* font */             Inter 14/1.5, "cv11" "ss01" features on
```

Full set lives at the top of `app/styles.css` under `:root`.

---

## Reference mocks

`reference/` contains the original three Stripe-flavored explorations
(Dashboard, Hero, Workspace) as static HTML, plus an `overview.html` that
links to all three. They're for visual comparison only — the wired app in
`app/` is the source of truth. The reference mocks contain a small JS
`animateNum` count-up; the wired PyScript app does not (and doesn't need to).

---

## Verification checklist

After dropping the files in, confirm:

- [ ] Open `index.html` → boot spinner disappears within ~2s, hero renders.
- [ ] Type a name + click *Add person* → row appears with initials avatar.
- [ ] Enter `Coffee · 14.40` paid by anyone → item appears with coffee icon.
- [ ] Try a description with `wine`, `cab`, `dinner`, `groceries`, `hotel`, and something generic → six different glyphs.
- [ ] Switch *Equally / By weight* mid-form → payer + participant selections survive.
- [ ] Hard-refresh the page → state persists from localStorage, trip name included.
- [ ] Resize down to ~440px wide → layout collapses to single column, item rows reflow to 3 grid areas.
- [ ] Browser console is clean.
