"""DOM rendering and event handlers — the only browser-aware UI module.

State flow: handler -> mutate AppState -> storage.save -> re-render regions.
Dynamic content is built with createElement + textContent (no innerHTML),
so user-entered names cannot inject markup. The one exception is
`_item_icon`, which sets a hardcoded SVG string from a fixed dict — no
user data ever flows into it.
"""

from pyscript import document, window
from pyscript.ffi import create_proxy

from splitcore.calc import parse_finite, per_person_totals, settle_up
from splitcore.model import MODE_EQUAL, MODE_UNEVEN, Item, Person

# Reject absurd magnitudes early (a finite 1e308 still poisons later math).
_MAX_AMOUNT = 1e9  # dollars

_state = None
_storage = None
_id_counter = 0
# Proxies created during a render. They must be destroyed before the next
# render or each mutation permanently leaks one proxy per row.
_render_proxies = []


# ---------- small DOM helpers ----------

def _qs(sel):
    return document.querySelector(sel)


def _qsa(sel):
    nodes = document.querySelectorAll(sel)
    return [nodes.item(i) for i in range(nodes.length)]


def _clear(node):
    while node.firstChild:
        node.removeChild(node.firstChild)


def _el(tag, text=None, cls=None):
    node = document.createElement(tag)
    if text is not None:
        node.textContent = text
    if cls is not None:
        node.className = cls
    return node


def _text(s):
    return document.createTextNode(s)


def _on(node, event, handler, track=True):
    proxy = create_proxy(handler)
    if track:
        _render_proxies.append(proxy)
    node.addEventListener(event, proxy)


def _money(cents):
    return "$%.2f" % (cents / 100.0)


def _money_plain(cents):
    return "%.2f" % (cents / 100.0)


# ---------- name + avatar ----------

def _initials(name):
    if not name:
        return "?"
    parts = [p for p in name.strip().split() if p]
    if not parts:
        return "?"
    if len(parts) == 1:
        return parts[0][:2].upper()
    return (parts[0][0] + parts[-1][0]).upper()


def _avatar(name, size=""):
    cls = "avatar"
    if size:
        cls += " " + size
    el = _el("span", _initials(name), cls)
    el.setAttribute("aria-hidden", "true")
    return el


# ---------- item icon (keyword match) ----------

_ICON_PATHS = {
    "food": (
        '<path d="M6 2v6a6 6 0 0 0 12 0V2"/>'
        '<path d="M6 8h12"/>'
    ),
    "drinks": (
        '<path d="M8 2h8"/>'
        '<path d="M12 2v6"/>'
        '<path d="M7 8c0 4 5 4 5 8v6"/>'
        '<path d="M17 8c0 4-5 4-5 8"/>'
        '<path d="M9 22h6"/>'
    ),
    "coffee": (
        '<path d="M17 8h1a3 3 0 0 1 0 6h-1"/>'
        '<path d="M3 8h14v8a4 4 0 0 1-4 4H7a4 4 0 0 1-4-4z"/>'
        '<path d="M6 1v3M10 1v3M14 1v3"/>'
    ),
    "transport": (
        '<circle cx="7" cy="17" r="2"/>'
        '<circle cx="17" cy="17" r="2"/>'
        '<path d="M5 17H3v-6l2-4h8l3 4h4a2 2 0 0 1 2 2v4h-2"/>'
    ),
    "groceries": (
        '<path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"/>'
        '<path d="M3 6h18"/>'
        '<path d="M16 10a4 4 0 0 1-8 0"/>'
    ),
    "lodging": (
        '<path d="M3 11l9-7 9 7"/>'
        '<path d="M5 10v10h14V10"/>'
        '<path d="M10 20v-6h4v6"/>'
    ),
    "default": (
        '<path d="M16 4h2a2 2 0 0 1 2 2v14l-3-2-3 2-3-2-3 2-3-2-3 2V6a2 2 0 0 1 2-2h2"/>'
        '<path d="M9 8h6"/><path d="M9 12h6"/><path d="M9 16h4"/>'
    ),
}

_ICON_KEYWORDS = [
    (["coffee", "latte", "espresso", "cappuccino", "tea", "matcha"], "coffee"),
    (["wine", "beer", "cocktail", "drink", "bar ", "whisky", "whiskey",
      "sake", "vodka", "rum", "gin", "champagne", "prosecco", "juice",
      "soda", "smoothie"], "drinks"),
    (["cab", "taxi", "uber", "lyft", "ride", "train", "bus", "flight",
      "fuel", "gas", "parking", "metro", "subway", "tram", "ferry",
      "car ", "rental"], "transport"),
    (["dinner", "lunch", "breakfast", "brunch", "food", "meal",
      "pizza", "burger", "sandwich", "taco", "sushi", "ramen", "noodle",
      "restaurant", "cafe", "kitchen", "marlow", "diner", "bistro"], "food"),
    (["groceries", "grocery", "market", "supermarket", "shopping",
      "store", "deli"], "groceries"),
    (["hotel", "airbnb", "motel", "lodging", "stay", "hostel", "inn"], "lodging"),
]


def _icon_kind(description):
    d = (description or "").lower()
    for keywords, kind in _ICON_KEYWORDS:
        for kw in keywords:
            if kw in d:
                return kind
    return "default"


def _item_icon(description):
    el = _el("span", None, "item-icon")
    kind = _icon_kind(description)
    paths = _ICON_PATHS.get(kind, _ICON_PATHS["default"])
    # SVG markup is hardcoded by us — no user input flows into innerHTML.
    el.innerHTML = (
        '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" '
        'stroke-width="2" stroke-linecap="round" stroke-linejoin="round">'
        + paths + '</svg>'
    )
    return el


# ---------- ledger row builders ----------

def _ledger_row(label, amount=None, cls="entry"):
    """Generic label + optional money row (kept for backwards compat)."""
    li = _el("li", None, cls)
    li.appendChild(_el("span", label, "label"))
    if amount is not None:
        li.appendChild(_el("span", amount, "amount"))
    return li


def _next_id(prefix):
    global _id_counter
    _id_counter += 1
    return "%s%d" % (prefix, _id_counter)


def _seed_counter():
    """Ensure generated ids never collide with ids loaded from storage."""
    global _id_counter
    biggest = 0
    for obj in list(_state.people) + list(_state.items):
        digits = "".join(ch for ch in obj.id if ch.isdigit())
        if digits:
            try:
                biggest = max(biggest, int(digits))
            except Exception:
                pass
    _id_counter = biggest


# ---------- rendering ----------

def _people_by_id():
    return {p.id: p for p in _state.people}


def _name(by_id, pid):
    person = by_id.get(pid)
    return person.name if person else "?"


def render_all():
    for proxy in _render_proxies:
        try:
            proxy.destroy()
        except Exception:
            pass
    _render_proxies.clear()
    _render_people()
    _render_item_form()
    _render_items()
    _render_hero()
    _render_shares()
    _render_settle()
    _update_helper()
    _update_counts()


def _paid_by_id():
    paid = {p.id: 0 for p in _state.people}
    for it in _state.items:
        if it.payer_id in paid:
            paid[it.payer_id] = paid[it.payer_id] + it.amount_cents
        else:
            paid[it.payer_id] = it.amount_cents
    return paid


def _render_people():
    box = _qs("#people-list")
    _clear(box)
    if not _state.people:
        li = _el("li", "No people yet. Add the first above.", "empty")
        box.appendChild(li)
        _qs("#people-error").textContent = ""
        return
    paid = _paid_by_id()
    for person in _state.people:
        li = _el("li", None, "entry")
        li.appendChild(_avatar(person.name, "sm"))
        wrap = _el("span")
        wrap.appendChild(_el("span", person.name, "person-name"))
        wrap.appendChild(_el("span", "paid " + _money(paid.get(person.id, 0)),
                             "person-meta"))
        li.appendChild(wrap)
        btn = _el("button", "Remove", "btn btn-danger-ghost")
        btn.type = "button"
        _on(btn, "click", _make_remove_person(person.id))
        li.appendChild(btn)
        box.appendChild(li)
    _qs("#people-error").textContent = ""


def _render_item_form(preserve=False):
    payer = _qs("#payer-select")
    prev_payer = payer.value if (preserve and payer.value) else ""

    prev_checks = {}
    prev_weights = {}
    if preserve:
        for cb in _qsa(".p-check"):
            prev_checks[cb.value] = cb.checked
        for w in _qsa(".p-weight"):
            pid = w.getAttribute("data-pid")
            prev_weights[pid] = w.value

    _clear(payer)
    if not _state.people:
        opt = _el("option", "— Add people first —")
        opt.value = ""
        opt.disabled = True
        opt.selected = True
        payer.appendChild(opt)
    for person in _state.people:
        opt = _el("option", person.name)
        opt.value = person.id
        if person.id == prev_payer:
            opt.selected = True
        payer.appendChild(opt)

    parts = _qs("#participants")
    _clear(parts)
    if not _state.people:
        li = _el("li", "Add people to choose participants.", "empty")
        parts.appendChild(li)
        return

    uneven = _qs("#mode-uneven").checked
    for person in _state.people:
        row = _el("li")
        cb = _el("input")
        cb.type = "checkbox"
        cb.value = person.id
        cb.className = "p-check check"
        # New people get checked by default; preserved ones keep prior state.
        cb.checked = prev_checks.get(person.id, True) if preserve else True
        row.appendChild(cb)
        row.appendChild(_avatar(person.name, "sm"))
        row.appendChild(_el("span", person.name, "person-name"))
        wt = _el("input")
        wt.type = "number"
        wt.value = prev_weights.get(person.id, "1") if preserve else "1"
        wt.min = "0"
        wt.step = "any"
        wt.className = "p-weight weight"
        wt.setAttribute("data-pid", person.id)
        if not uneven:
            wt.disabled = True
        row.appendChild(wt)
        parts.appendChild(row)


def _render_items():
    box = _qs("#items-list")
    _clear(box)
    if not _state.items:
        li = _el("li", "No items yet. Add an expense to start the ledger.",
                 "empty empty-row")
        box.appendChild(li)
        return
    by_id = _people_by_id()
    # Newest first
    for it in reversed(_state.items):
        li = _el("li")
        li.appendChild(_item_icon(it.description))

        body = _el("div", None, "item-body")
        body.appendChild(_el("div", it.description or "Untitled", "item-title"))
        meta = _el("div", None, "item-meta")
        meta.appendChild(_text("Paid by "))
        meta.appendChild(_el("b", _name(by_id, it.payer_id)))
        meta.appendChild(_el("span", " · ", "bullet"))
        n_parts = len(it.participant_ids)
        meta.appendChild(_text("Among "))
        if n_parts <= 3:
            names = ", ".join(_name(by_id, pid) for pid in it.participant_ids)
            meta.appendChild(_el("b", names))
        else:
            meta.appendChild(_el("b", "%d people" % n_parts))
        body.appendChild(meta)
        li.appendChild(body)

        mode = it.split_mode()
        if mode == MODE_UNEVEN:
            weights = it.weights()
            w_str = "·".join(
                ("%g" % parse_finite(weights.get(pid, 0)))
                if parse_finite(weights.get(pid, 0)) is not None else "0"
                for pid in it.participant_ids
            )
            badge = _el("span", "Uneven · " + w_str, "badge uneven")
        else:
            badge = _el("span", "Equally", "badge")
        li.appendChild(badge)

        li.appendChild(_el("span", _money(it.amount_cents), "item-amount"))

        btn = _el("button", "Remove", "btn btn-danger-ghost item-del")
        btn.type = "button"
        btn.setAttribute("aria-label", "Remove " + (it.description or "item"))
        _on(btn, "click", _make_remove_item(it.id))
        li.appendChild(btn)

        box.appendChild(li)


def _render_hero():
    inner = _qs("#hero-inner")
    _clear(inner)

    n_people = len(_state.people)
    n_items = len(_state.items)
    total_cents = sum(it.amount_cents for it in _state.items)

    try:
        totals = per_person_totals(_state)
    except Exception as e:
        window.console.warn("vvsplit: totals failed: " + str(e))
        totals = {}
    try:
        transfers = settle_up(_state)
    except Exception as e:
        window.console.warn("vvsplit: settle-up failed: " + str(e))
        transfers = []

    paid = _paid_by_id()
    by_id = _people_by_id()

    # Largest share
    largest = None
    if totals:
        pid = max(totals, key=lambda k: totals.get(k, 0))
        if totals.get(pid, 0) > 0 and pid in by_id:
            largest = (by_id[pid].name, totals[pid])

    # Biggest payer
    paid_most = None
    if paid:
        pid = max(paid, key=lambda k: paid.get(k, 0))
        if paid.get(pid, 0) > 0 and pid in by_id:
            paid_most = (by_id[pid].name, paid[pid])

    # Biggest debt (most negative net)
    biggest_debt = None
    if n_people:
        net = {p.id: paid.get(p.id, 0) - totals.get(p.id, 0)
               for p in _state.people}
        pid = min(net, key=lambda k: net[k])
        if net.get(pid, 0) < 0 and pid in by_id:
            biggest_debt = (by_id[pid].name, -net[pid])

    # ---- LEFT side ----
    left = _el("div")

    eyebrow = _el("div", None, "hero-eyebrow")
    dot = _el("span", None, "gd-dot")
    dot.setAttribute("aria-hidden", "true")
    eyebrow.appendChild(dot)
    eyebrow.appendChild(_el("span", "Split summary"))
    left.appendChild(eyebrow)

    h1 = _el("h1")
    h1.appendChild(_text("$"))
    amt = _el("span", _money_plain(total_cents), "accent num")
    amt.id = "hero-total"
    h1.appendChild(amt)
    left.appendChild(h1)

    sub = _el("p", None, "hero-sub")
    items_word = "item" if n_items == 1 else "items"
    people_word = "person" if n_people == 1 else "people"
    if n_people == 0:
        sub.textContent = (
            "Add people, then log an expense to see who owes whom."
        )
    elif n_items == 0:
        sub.textContent = (
            "%d %s ready. Add an expense to get started."
            % (n_people, people_word)
        )
    elif not transfers:
        sub.textContent = (
            "%d %s billed across %d %s — everyone's square."
            % (n_items, items_word, n_people, people_word)
        )
    else:
        n_t = len(transfers)
        t_word = "transfer" if n_t == 1 else "transfers"
        sub.appendChild(_text(
            "%d %s billed across %d %s. " % (
                n_items, items_word, n_people, people_word)
        ))
        sub.appendChild(_text("It takes "))
        sub.appendChild(_el("b", "%d %s" % (n_t, t_word)))
        sub.appendChild(_text(" to settle up."))
    left.appendChild(sub)

    stats = _el("div", None, "hero-stats")

    def _stat(k, v):
        cell = _el("div", None, "hero-stat")
        cell.appendChild(_el("div", k, "k"))
        cell.appendChild(_el("div", v, "v"))
        return cell

    stats.appendChild(_stat("Items", str(n_items)))
    stats.appendChild(_stat("People", str(n_people)))
    stats.appendChild(_stat("Transfers", str(len(transfers))))
    if largest:
        cell = _el("div", None, "hero-stat")
        cell.appendChild(_el("div", "Largest share", "k"))
        v = _el("div", None, "v")
        v.appendChild(_text(largest[0] + " · "))
        v.appendChild(_text(_money(largest[1])))
        cell.appendChild(v)
        stats.appendChild(cell)
    left.appendChild(stats)

    inner.appendChild(left)

    # ---- RIGHT side ----
    aside = _el("aside", None, "total-card")

    if n_items == 0:
        aside.appendChild(_el("div", "Status", "lbl"))
        aside.appendChild(_el("div", "Empty", "big muted"))
        meta = _el("div", None, "meta-row")
        c1 = _el("div", None, "meta-cell")
        c1.appendChild(_el("div", "People", "k"))
        c1.appendChild(_el("div", str(n_people), "v"))
        meta.appendChild(c1)
        c2 = _el("div", None, "meta-cell")
        c2.appendChild(_el("div", "Items", "k"))
        c2.appendChild(_el("div", "0", "v"))
        meta.appendChild(c2)
        aside.appendChild(meta)
    elif not transfers:
        aside.appendChild(_el("div", "Status", "lbl"))
        aside.appendChild(_el("div", "All square", "big"))
        meta = _el("div", None, "meta-row")
        c1 = _el("div", None, "meta-cell")
        c1.appendChild(_el("div", "Items", "k"))
        c1.appendChild(_el("div", str(n_items), "v"))
        meta.appendChild(c1)
        c2 = _el("div", None, "meta-cell")
        c2.appendChild(_el("div", "Total billed", "k"))
        c2.appendChild(_el("div", _money(total_cents), "v"))
        meta.appendChild(c2)
        aside.appendChild(meta)
    else:
        n_t = len(transfers)
        aside.appendChild(_el("div", "Settle up", "lbl"))
        big = _el("div", None, "big")
        big.appendChild(_el("span", str(n_t)))
        big.appendChild(_el("span",
            " " + ("transfer" if n_t == 1 else "transfers"), "currency"))
        aside.appendChild(big)
        meta = _el("div", None, "meta-row")
        if paid_most:
            c1 = _el("div", None, "meta-cell")
            c1.appendChild(_el("div", "Biggest payer", "k"))
            v = _el("div", None, "v")
            v.appendChild(_text(paid_most[0] + " · "))
            mu = _el("span", _money(paid_most[1]), "muted")
            v.appendChild(mu)
            c1.appendChild(v)
            meta.appendChild(c1)
        if biggest_debt:
            c2 = _el("div", None, "meta-cell")
            c2.appendChild(_el("div", "Biggest debt", "k"))
            v = _el("div", None, "v")
            v.appendChild(_text(biggest_debt[0] + " · "))
            mu = _el("span", _money(biggest_debt[1]), "muted")
            v.appendChild(mu)
            c2.appendChild(v)
            meta.appendChild(c2)
        aside.appendChild(meta)

    inner.appendChild(aside)


def _render_shares():
    box = _qs("#shares-list")
    _clear(box)
    sub = _qs("#shares-sub")

    try:
        totals = per_person_totals(_state)
    except Exception as e:
        window.console.warn("vvsplit: totals failed: " + str(e))
        totals = {}

    total_cents = sum(it.amount_cents for it in _state.items)
    if sub:
        if total_cents > 0:
            sub.textContent = (
                "What everyone owes against the total of "
                + _money(total_cents) + "."
            )
        else:
            sub.textContent = "What everyone owes against the total."

    if not _state.people:
        li = _el("li", "Add people to see shares.", "empty")
        box.appendChild(li)
        return
    if not _state.items:
        li = _el("li", "No expenses yet — nothing to share.", "empty")
        box.appendChild(li)
        return

    # Sort by share desc for visual rhythm
    people_sorted = sorted(
        _state.people,
        key=lambda p: -totals.get(p.id, 0),
    )
    max_share = max((totals.get(p.id, 0) for p in _state.people), default=0)
    if max_share <= 0:
        max_share = 1  # avoid div-by-zero; bars will just be 0

    for p in people_sorted:
        share = totals.get(p.id, 0)
        li = _el("li")
        row = _el("div", None, "share-row")
        row.appendChild(_avatar(p.name, "sm"))
        cell = _el("div", None, "share-cell")
        top = _el("div", None, "top")
        top.appendChild(_el("span", p.name, "share-name"))
        top.appendChild(_el("span", _money(share), "share-amt"))
        cell.appendChild(top)
        bar = _el("div", None, "share-bar")
        fill = _el("span", None, "share-bar-fill")
        scale = (share / max_share) if max_share > 0 else 0
        fill.style.setProperty("--scale", "%.4f" % scale)
        bar.appendChild(fill)
        cell.appendChild(bar)
        row.appendChild(cell)
        li.appendChild(row)
        box.appendChild(li)


def _render_settle():
    box = _qs("#transfers-list")
    _clear(box)
    sub = _qs("#settle-sub")

    try:
        transfers = settle_up(_state)
    except Exception as e:
        window.console.warn("vvsplit: settle-up failed: " + str(e))
        transfers = []

    by_id = _people_by_id()

    if not _state.people or not _state.items:
        if sub:
            sub.textContent = "Add people and an expense to compute transfers."
        li = _el("li", "Nothing to settle yet.", "empty")
        box.appendChild(li)
        return

    if not transfers:
        if sub:
            sub.textContent = "Everyone is already settled — no transfers needed."
        li = _el("li", "All settled — no transfers needed.", "empty")
        box.appendChild(li)
        return

    n_t = len(transfers)
    if sub:
        sub.textContent = (
            "%d %s will settle the bill."
            % (n_t, "transfer" if n_t == 1 else "transfers")
        )

    for debtor, creditor, amount in transfers:
        li = _el("li", None, "transfer")
        trio = _el("div", None, "trio")

        d_name = _name(by_id, debtor)
        c_name = _name(by_id, creditor)

        d_av = _avatar(d_name, "sm")
        d_av.classList.add("av")
        trio.appendChild(d_av)
        trio.appendChild(_el("span", d_name, "name"))

        arr = _el("span", "→", "arr")
        arr.setAttribute("aria-hidden", "true")
        trio.appendChild(arr)

        c_av = _avatar(c_name, "sm")
        c_av.classList.add("av")
        trio.appendChild(c_av)
        trio.appendChild(_el("span", c_name, "name"))

        li.appendChild(trio)
        li.appendChild(_el("span", _money(amount), "transfer-amount"))
        box.appendChild(li)


def _update_counts():
    pc = _qs("#people-count")
    if pc:
        pc.textContent = "%d %s" % (
            len(_state.people),
            "person" if len(_state.people) == 1 else "people",
        )
    ic = _qs("#items-count")
    if ic:
        ic.textContent = "%d %s" % (
            len(_state.items),
            "item" if len(_state.items) == 1 else "items",
        )


def _update_helper():
    """The little 'Each participant pays $X.XX' text under the add-item form.
    Updates on every checkbox/weight/amount change as well as renders."""
    helper = _qs("#add-item-helper")
    if not helper:
        return
    amount = parse_finite(_qs("#item-amount").value.strip())
    if amount is None or amount <= 0:
        helper.textContent = "Enter an amount to preview the split."
        return
    checked = [c for c in _qsa(".p-check") if c.checked]
    n = len(checked)
    if n == 0:
        helper.textContent = "Pick at least one participant."
        return
    uneven = _qs("#mode-uneven").checked
    if uneven:
        # Show the largest single share.
        weights_map = {}
        for w in _qsa(".p-weight"):
            pid = w.getAttribute("data-pid")
            weights_map[pid] = parse_finite(w.value)
        total_w = 0.0
        for c in checked:
            v = weights_map.get(c.value)
            if v is not None and v > 0:
                total_w += v
        if total_w <= 0:
            helper.textContent = "Weights cannot all be zero."
            return
        # Largest share among checked
        biggest = 0.0
        for c in checked:
            v = weights_map.get(c.value)
            if v is not None and v > 0:
                share = amount * v / total_w
                if share > biggest:
                    biggest = share
        _clear(helper)
        helper.appendChild(_text("Largest share "))
        helper.appendChild(_el("b", "$%.2f" % biggest))
        helper.appendChild(_text(" · weighted across "))
        helper.appendChild(_el("b", "%d" % n))
        helper.appendChild(_text(" participant" + ("" if n == 1 else "s")))
    else:
        each = amount / n
        _clear(helper)
        helper.appendChild(_text("Each participant pays "))
        helper.appendChild(_el("b", "$%.2f" % each))
        if n > 1:
            helper.appendChild(_text(" · split %d ways" % n))


# ---------- saved pill ----------

def _set_saved(kind, label=None):
    """kind: 'saved' | 'saving' | 'error'."""
    pill = _qs("#saved-pill")
    if not pill:
        return
    pill.className = "saved-pill" + (" " + kind if kind != "saved" else "")
    text = pill.querySelector(".saved-pill-text")
    if text:
        if label is not None:
            text.textContent = label
        elif kind == "saved":
            text.textContent = "Saved locally"
        elif kind == "saving":
            text.textContent = "Saving…"
        elif kind == "error":
            text.textContent = "Save failed"


def _persist_and_render():
    """Save then re-render. A storage failure (quota, private mode) must not
    desync memory from the DOM or surface a traceback — log and still render.
    """
    _set_saved("saving")
    try:
        _storage.save(_state)
        _set_saved("saved")
    except Exception as e:
        window.console.warn("vvsplit: could not save: " + str(e))
        _set_saved("error")
    render_all()


# ---------- handlers ----------

def on_add_person(event):
    field = _qs("#person-name")
    name = field.value.strip()
    err = _qs("#people-error")
    if not name:
        err.textContent = "Enter a name."
        return
    if len(name) > 80:
        err.textContent = "That name is too long."
        return
    if any(p.name == name for p in _state.people):
        err.textContent = "That name already exists."
        return
    _state.people.append(Person(_next_id("p"), name))
    field.value = ""
    _persist_and_render()


def on_person_key(event):
    if event.key == "Enter":
        on_add_person(event)


def _make_remove_person(pid):
    def handler(event):
        refs = _state.items_referencing(pid)
        if refs:
            descs = ", ".join(i.description or "untitled" for i in refs)
            _qs("#people-error").textContent = (
                "Can't remove — used by item(s): " + descs
            )
            return
        _state.people = [p for p in _state.people if p.id != pid]
        _persist_and_render()
    return handler


def on_mode_change(event):
    _render_item_form(preserve=True)
    _update_helper()


def on_form_change(event):
    """Bubbles from #participants and the amount/desc fields. Cheap re-update
    of the helper text without re-rendering the whole form."""
    _update_helper()


def _select_share_field(event):
    """Select a share field's text on focus/click so the value can be
    replaced with one keystroke. Delegated from the persistent
    #participants container, so it survives form re-renders."""
    el = event.target
    if hasattr(el, "classList") and el.classList.contains("p-weight"):
        el.select()


def on_add_item(event):
    err = _qs("#item-error")
    err.textContent = ""

    if not _state.people:
        err.textContent = "Add at least one person first."
        return

    desc = _qs("#item-desc").value.strip()
    if not desc:
        err.textContent = "Enter a description."
        return
    if len(desc) > 200:
        err.textContent = "That description is too long."
        return

    amount = parse_finite(_qs("#item-amount").value.strip())
    if amount is None:
        err.textContent = "Amount must be a number."
        return
    if amount > _MAX_AMOUNT:
        err.textContent = "Amount is unreasonably large."
        return
    amount_cents = int(round(amount * 100))
    if amount_cents <= 0:
        err.textContent = "Amount must be greater than zero."
        return

    payer_id = _qs("#payer-select").value
    if not payer_id or _state.person_by_id(payer_id) is None:
        err.textContent = "Select who paid."
        return

    checked = [c for c in _qsa(".p-check") if c.checked]
    participant_ids = [c.value for c in checked]
    if not participant_ids:
        err.textContent = "Pick at least one participant."
        return

    uneven = _qs("#mode-uneven").checked
    if uneven:
        weights = {}
        for w in _qsa(".p-weight"):
            pid = w.getAttribute("data-pid")
            if pid in participant_ids:
                val = parse_finite(w.value)
                if val is None:
                    err.textContent = "Weights must be numbers."
                    return
                if val < 0:
                    err.textContent = "Weights cannot be negative."
                    return
                weights[pid] = val
        if sum(weights.values()) <= 0:
            err.textContent = "Weights cannot all be zero."
            return
        split = {"mode": MODE_UNEVEN, "weights": weights}
    else:
        split = {"mode": MODE_EQUAL}

    _state.items.append(Item(
        _next_id("i"), desc, amount_cents, payer_id, participant_ids, split))
    _qs("#item-desc").value = ""
    _qs("#item-amount").value = ""
    _persist_and_render()


def _make_remove_item(iid):
    def handler(event):
        _state.items = [i for i in _state.items if i.id != iid]
        _persist_and_render()
    return handler


def on_trip_change(event):
    val = _qs("#trip-name").value.strip()
    if val == _state.trip_name:
        return
    _state.trip_name = val
    _set_saved("saving")
    try:
        _storage.save(_state)
        _set_saved("saved")
    except Exception as e:
        window.console.warn("vvsplit: could not save trip name: " + str(e))
        _set_saved("error")


# ---------- entry ----------

def start(state, storage_module):
    global _state, _storage
    _state = state
    _storage = storage_module
    _seed_counter()

    # Bind trip name (debounce: save on blur and on change of focus elsewhere)
    trip_input = _qs("#trip-name")
    if trip_input:
        trip_input.value = _state.trip_name or ""
        _on(trip_input, "change", on_trip_change, track=False)
        _on(trip_input, "blur", on_trip_change, track=False)

    _on(_qs("#add-person"), "click", on_add_person, track=False)
    _on(_qs("#person-name"), "keydown", on_person_key, track=False)
    _on(_qs("#add-item"), "click", on_add_item, track=False)
    _on(_qs("#mode-equal"), "change", on_mode_change, track=False)
    _on(_qs("#mode-uneven"), "change", on_mode_change, track=False)
    _on(_qs("#item-amount"), "input", on_form_change, track=False)

    parts = _qs("#participants")
    _on(parts, "focusin", _select_share_field, track=False)
    _on(parts, "click", _select_share_field, track=False)
    _on(parts, "change", on_form_change, track=False)
    _on(parts, "input", on_form_change, track=False)

    render_all()
    _set_saved("saved")

    boot = _qs("#boot-msg")
    if boot:
        boot.remove()
